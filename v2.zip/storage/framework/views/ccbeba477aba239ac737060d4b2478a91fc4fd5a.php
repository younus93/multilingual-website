<table>
    <tr>
        <td>Name</td>
        <td><?php echo e($Name); ?></td>
    </tr>
    <tr>
        <td>Phone</td>
        <td><?php echo e($Phone); ?></td>
    </tr>
    <?php if(!$Address): ?>
    <tr>
        <td>Address</td>
        <td><?php echo e($Address); ?></td>
    </tr>
    <?php endif; ?>
    <?php if(!$Email): ?>
    <tr>
        <td>$Email</td>
        <td><?php echo e($Email); ?></td>
    </tr>
    <?php endif; ?>
    <?php if(!$Company_Name): ?>
    <tr>
        <td>Company Name</td>
        <td><?php echo e($Company_Name); ?></td>
    </tr>
    <?php endif; ?>
    <?php if(!$Message): ?>
    <tr>
        <td>Message</td>
        <td><?php echo e($Message); ?></td>
    </tr>
    <?php endif; ?>
    <tr>
        <td>Sent at</td>
        <td><?php echo e($Sent_at); ?></td>
    </tr>
</table>
<?php $__env->startSection('content'); ?>

    <div class="page-title-style02 pt-bkg01">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="breadcrumb-container">
                        <ul class="breadcrumb clearfix">
                            <li>You are here:</li>

                            <li>
                                <a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>

                            <li>
                                <a href="#">Truck Owners</a>
                            </li>
                        </ul><!-- .breadcrumb end -->
                    </div><!-- .breadcrumb-container end -->
                </div><!-- .col-md-12 end -->
            </div><!-- .row end -->
        </div><!-- .container end -->
    </div><!-- .page-title-style01.page-title-negative-top end -->

    <div class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="custom-heading">
                        <h2><?php echo e(trans('messages.to_heading')); ?></h2>
                    </div><!-- .custom-heading end -->

                    <p>
                       <?php echo e(trans('messages.to_msg')); ?>

                    </p>

                    <ul class="fa-ul">
                        <li>
                            <i class="fa fa-li fa-long-arrow-right"></i>
                            <?php echo e(trans('messages.to1')); ?>

                        </li>

                        <li>
                            <i class="fa fa-li fa-long-arrow-right"></i>
                            <?php echo e(trans('messages.to2')); ?>

                        </li>

                        <li>
                            <i class="fa fa-li fa-long-arrow-right"></i>
                            <?php echo e(trans('messages.to3')); ?>

                        </li>

                        <li>
                            <i class="fa fa-li fa-long-arrow-right"></i>
                            <?php echo e(trans('messages.to4')); ?>

                        </li>

                        <li>
                            <i class="fa fa-li fa-long-arrow-right"></i>
                            <?php echo e(trans('messages.to5')); ?>

                        </li>

                        <li>
                            <i class="fa fa-li fa-long-arrow-right"></i>
                            <?php echo e(trans('messages.to6')); ?>

                        </li>
                    </ul><!-- .fa-ul end -->

                    <p>
                        <?php echo e(trans('messages.to_msg_1')); ?>

                    </p>

                </div><!-- .col-md-6 end -->

                <div class="col-md-6 animated triggerAnimation" data-animate="zoomIn">
                    <img src="img/pics/warehouse.jpg" alt=""/>
                </div><!-- .col-md-6 end -->
            </div><!-- .row end -->
        </div><!-- .container end -->
    </div><!-- .page-content end -->

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="custom-heading02" style="margin-bottom:30px;">
                    <h2><?php echo e(trans('messages.truckjee_finds_loads')); ?></h2>
                    <p>
                        <?php echo e(trans('messages.run_truck')); ?>

                    </p>
                </div><!-- .custom-heading02 end -->
            </div><!-- .col-md-12 end -->
        </div><!-- .row end -->
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <img src="img/pics/truckowner.png" alt="">
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="custom-heading">
                    <h2><?php echo e(trans('messages.make_it_simple')); ?></h2>
                </div><!-- .custom-heading end -->
                <p class="text-big">
                    <?php echo e(trans('messages.make_it_simple_msg')); ?>

                </p>
                <p>
                    <?php echo e(trans('messages.make_it_simple_msg_1')); ?>


                </p>
                <ul class="service-list-big-icons-details">
                    <li>
                        <div class="icon-container">
                            <img class="animated triggerAnimation" data-animate="zoomIn" src="img/svg/pi-delivery-2.svg" alt="checklist icon"/>
                        </div><!-- .icon-container end -->



                        <div class="service-details">
                            <h4><?php echo e(trans('messages.notify')); ?></h4>

                            <p>
                                <?php echo e(trans('messages.notify_msg')); ?>

                            </p>
                        </div><!-- .service-details end -->
                    </li>

                    <li>
                        <div class="icon-container">
                            <img class="animated triggerAnimation" data-animate="zoomIn" src="img/svg/pi-map-1.svg" alt="clock icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h4><?php echo e(trans('messages.get_loads')); ?></h4>

                            <p>
                                <?php echo e(trans('messages.get_loads_msg')); ?>

                            </p>
                        </div><!-- .service-details end -->
                    </li>

                    <li>
                        <div class="icon-container">
                            <img class="animated triggerAnimation" data-animate="zoomIn" src="img/svg/pi-globe-9.svg" alt="truck icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h4><?php echo e(trans('messages.select')); ?></h4>

                            <p>
                                <?php echo e(trans('messages.select_msg')); ?>

                            </p>
                        </div><!-- .service-details end -->
                    </li>

                    <li>
                        <div class="icon-container">
                            <img class="animated triggerAnimation" data-animate="zoomIn" src="img/svg/pi-touch-desktop.svg" alt="touch icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h4><?php echo e(trans('messages.transaction')); ?></h4>

                            <p>
                                <?php echo e(trans('messages.transaction_msg_to')); ?>

                            </p>
                        </div><!-- .service-details end -->
                    </li>
                    <li>
                        <div class="icon-container">
                            <img class="animated triggerAnimation" data-animate="zoomIn" src="img/svg/pi-graph.svg" alt="touch icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h4><?php echo e(trans('messages.balance_payments')); ?></h4>
                            <p>
                                <?php echo e(trans('messages.balance_payments_msg')); ?>

                            </p>
                        </div><!-- .service-details end -->
                    </li>
                </ul><!-- .service-list-big-icons-details end -->
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="custom-heading02" style="margin-bottom:30px;">
                    <h2>Get in touch</h2>
                    <p>
                        Please fill your details and we would get back to you shortly.
                    </p>
                </div><!-- .custom-heading02 end -->
            </div><!-- .col-md-12 end -->
        </div><!-- .row end -->
    </div>

    <!-- Request a callback Section -->
    <div class="container" id="tf">
        <div class="row">
            <div class="col-md-6 col-sm-6">
                <div id="loader">
                    <img src="img/loader.gif" alt="loading" style="height:150px;width: 150px;">
                    <p>Please wait</p>
                </div>
                <form id="truckOwnersForm">
                    <p>Fields marked with * are required</p>

                    <!-- Name form field -->
                    <div class="form-group">
                        <?php echo Form::label('Name','* Name:'); ?>

                        <?php echo Form::text('Name',null,['class'=>'form-control']); ?>

                    </div>

                    <!-- Phone form field -->
                    <div class="form-group">
                        <?php echo Form::label('Phone','* Phone(+91):'); ?>

                        <?php echo Form::text('Phone',null,['class'=>'form-control']); ?>

                    </div>

                    <!-- Email form field -->
                    <div class="form-group">
                        <?php echo Form::label('Email','* Email:'); ?>

                        <?php echo Form::text('Email',null,['class'=>'form-control']); ?>

                    </div>

                    <!-- Address form field -->
                    <div class="form-group">
                        <?php echo Form::label('Address','* Address:'); ?>

                        <?php echo Form::textarea('Address',null,['class'=>'form-control', 'rows'=>5]); ?>

                    </div>
                    <!-- Submit button -->
                    <div class="form-group">
                        <?php echo Form::submit('Submit',['class'=>'btn btn-yellow form-control']); ?>

                    </div>
                </form>
                <div class="alert" id="truckOwnersFormAlert">
                </div>
                <?php $__env->startSection('scripts'); ?>
                    <script>
                        //Transporter form
                        $('#truckOwnersFormAlert').hide();
                        $('#loader').hide();
                        $('#truckOwnersForm').on('submit',function(e){
                            e.preventDefault();
                            $('#truckOwnersFormAlert').html("");
                            $('#truckOwnersForm').hide();
                            $('#loader').show();
                            $.ajax({

                                type    :   'POST',
                                url     :   '/forms/6',
                                data    :   $('#truckOwnersForm').serialize(),
                                success :   function(msg){
                                    $('#truckOwnersForm').slideUp(1000);
                                    $('#loader').hide();
                                    $('#truckOwnersFormAlert').append("<h3>"+msg.success+"</h3>");
                                    $('#truckOwnersFormAlert').append("<h4><a href='<?php echo e(url('truck-owners')); ?>'>Click here to submit another enquiry.</a></h4>");
                                    $('#truckOwnersFormAlert').show();
                                },
                                error   : function(xhr,status, response){
                                    var error = jQuery.parseJSON(xhr.responseText);  // this section is key player in getting the value of the errors from controller.
                                    console.log(error);
                                    $('#truckOwnersFormAlert').append('<ul>');
                                    for(var k in error.errors){
                                        if(error.errors.hasOwnProperty(k)){
                                            error.errors[k].forEach(function(val){
                                                $('#truckOwnersFormAlert').append('<li>' + val + '</li>');
                                            });
                                        }
                                    }
                                    $('#loader').hide();
                                    $('#truckOwnersForm').show();
                                    $('#truckOwnersFormAlert').show();
                                }
                            });
                        });
                    </script>
                <?php $__env->stopSection(); ?>
            </div>
            <div class="col-md-6 col-sm-6">
                <img src="img/pics/truckownercontact.png" alt="truck owner contact">
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
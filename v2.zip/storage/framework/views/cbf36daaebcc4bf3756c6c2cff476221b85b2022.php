<table>
    <tr>
        <td>Name</td>
        <td><?php echo e($Name); ?></td>
    </tr>
    <tr>
        <td>Phone</td>
        <td><?php echo e($Phone); ?></td>
    </tr>
    <tr>
        <td>Company Name</td>
        <td><?php echo e($Company_Name); ?></td>
    </tr>
    <tr>
        <td>Email</td>
        <td><?php echo e($Email); ?></td>
    </tr>
    <tr>
        <td>Address</td>
        <td><?php echo e($Address); ?></td>
    </tr>
    <tr>
        <td>Sent at</td>
        <td><?php echo e(\Carbon\Carbon::now()); ?></td>
    </tr>
</table>
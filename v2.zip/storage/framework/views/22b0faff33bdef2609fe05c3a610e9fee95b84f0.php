<?php $__env->startSection('content'); ?>

    <div class="page-title-style01" style="margin-top:25px;margin-bottom:25px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="custom-heading02" style="margin-bottom:30px;">
                        <h2>What we Offer</h2>
                        <p>
                            TRANSPARENT LOGISTIC SERVICES
                        </p>
                    </div><!-- .custom-heading02 end -->
                </div><!-- .col-md-12 end -->
            </div><!-- .row end -->

            <div class="row mb-30">
                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-truck-1.svg" alt="checklist icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>Verified Truck Owners</h3>

                            <p>
                                Transporting cargo on the Indian Highway has never been this easy before. TruckJee helps you to find truck owners who are willing to do business with you.
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->

                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-officer.svg" alt="warehouse icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>Huge Transporter base</h3>

                            <p>
                                Its time to stop worrying about finding loads for your trucks. You are assured to run your trucks with full loads all year long irrespective of the month or season or market condition.
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->
            </div><!-- .row.mb-30 end -->

            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-map-3.svg" alt="map icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>Real Time Tracking</h3>

                            <p>
                                All trucks matched through TruckJee are equiped with realtime GPS Tracking systems. It is time you stop worrying about the location of your cargo.
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->

                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-availability-2.svg" alt="touch icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>Accessibility</h3>

                            <p>
                                TruckJee makes your transportation activities easy and accessible. Whether you are sitting in your office or taking a vacation, you can monitor your transportation activities at ease.
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->
            </div><!-- .row.mb-30 end -->

            <div class="row">
                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-graph.svg" alt="graph icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>More return on Investments</h3>

                            <p>
                                Whether you are a transporter or a fleet owner, TruckJee enables you to run your business all year long. Watch your business yeild more by using TruckJee.
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->

                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-touch-desktop.svg" alt="touch icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>Online Portal</h3>

                            <p>
                                All your transportation activities are available at one place. Exhaustive documentation and automatic monitoring ensures that you are never lost for information when you need it.
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->
            </div><!-- .row.mb-30 end -->


        </div><!-- .container end -->
    </div><!-- .page-content end -->


    <!-- Are you a Transporter or truck owner section -->

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="custom-heading02" style="margin-bottom:30px;">
                    <h2>Get in touch</h2>
                    <p>
                        Please fill your details and we would get back to you shortly.
                    </p>
                </div><!-- .custom-heading02 end -->
            </div><!-- .col-md-12 end -->
        </div><!-- .row end -->
    </div>

    <!-- Request a callback Section -->
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6">

            </div>
            <div class="col-md-6 col-sm-6">
                <form class="wpcf7 clearfix">
                    <fieldset>
                        <label>
                            <span class="required">*</span> Your request:
                        </label>

                        <select class="wpcf7-form-control-wrap wpcf7-select" id="contact-inquiry">
                            <option value="I am a Transporter">I am a Transporter</option>
                            <option value="I am a Truck Owner">I am a Truck Owner</option>
                            <option value="Other">Other</option>
                        </select>
                    </fieldset>

                    <fieldset>
                        <label>
                            <span class="required">*</span> Name:
                        </label>

                        <input type="text" class="wpcf7-text" id="contact-name">
                    </fieldset>

                    <fieldset>
                        <label>
                            <span class="required">*</span> Phone:
                        </label>

                        <input type="text" class="wpcf7-text" id="contact-phone">
                    </fieldset>

                    <fieldset>
                        <label>
                            <span class="required">*</span> Email:
                        </label>

                        <input type="url" class="wpcf7-text" id="contact-email">
                    </fieldset>

                    <input type="submit" class="wpcf7-submit" value="send" />
                </form><!-- .wpcf7 end -->
            </div>
        </div>
    </div>
    <div class="page-title-style01 to-tp">
        <div class="container">

            <div class="row mb-30">
                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-truck-3.svg" alt="checklist icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>Are you a Truck Owner?</h3>

                            <p>
                                TruckJee enables you to run your trucks all around the year with full loads.
                            </p>
                            <p>
                                <a href="#" class="btn">Know More</a>
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->

                <div class="col-md-6 col-sm-6">
                    <div class="service-icon-left-boxed">
                        <div class="icon-container animated triggerAnimation" data-animate="zoomIn">
                            <img src="img/svg/pi-cargo-retail.svg" alt="warehouse icon"/>
                        </div><!-- .icon-container end -->

                        <div class="service-details">
                            <h3>Are you a Transporter?</h3>

                            <p>
                                TruckJee garuntees you atleast 8-20% reduction in your truck hiring cost.
                            </p>
                            <p>
                                <a href="#" class="btn">Know More</a>
                            </p>
                        </div><!-- .service-details end -->
                    </div><!-- .service-icon-left-boxed end -->
                </div><!-- .col-md-6 end -->
            </div><!-- .row.mb-30 end -->
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>